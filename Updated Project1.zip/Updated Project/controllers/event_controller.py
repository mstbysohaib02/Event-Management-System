from db_config import get_connection

def add_event(name, desc, date, time, venue_id):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO events (name, description, date, time, venue_id)
        VALUES (%s, %s, %s, %s, %s)
    """, (name, desc, date, time, venue_id))
    conn.commit()
    cursor.close()
    conn.close()

def get_all_events():
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("""
        SELECT 
            e.event_id,
            e.name,
            e.description,
            e.date,
            e.time,
            v.name AS venue
        FROM events e
        JOIN venues v ON e.venue_id = v.venue_id
    """)
    events = cursor.fetchall()
    cursor.close()
    conn.close()
    return events
