# controllers/venue_controller.py

from db_config import get_connection

def get_all_venues():
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT venue_id, name FROM venues")
    venues = cursor.fetchall()
    conn.close()
    return venues
