-- Venues


INSERT INTO venues (name, location, capacity) VALUES 
('Grand Hall', 'Downtown', 300),
('Tech Park Auditorium', 'Sector 5', 500);

-- Users
INSERT INTO users (username, email) VALUES
('alice', 'alice@example.com'),
('bob', 'bob@example.com');

-- Events
INSERT INTO events (name, description, date, time, venue_id) VALUES
('Tech Talk AI', 'Intro to AI and ML', '2025-06-01', '10:00:00', 1),
('Cybersecurity 101', 'Protecting Digital Assets', '2025-06-05', '14:00:00', 2);
