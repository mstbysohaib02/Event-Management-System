DELIMITER //

CREATE PROCEDURE RegisterUserForEvent(IN uid INT, IN eid INT)
BEGIN
  INSERT INTO registrations(user_id, event_id)
  VALUES(uid, eid);
END //

DELIMITER ;
