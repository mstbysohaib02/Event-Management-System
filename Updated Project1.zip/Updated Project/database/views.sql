CREATE VIEW event_attendees AS
SELECT 
    e.name AS event_name,
    u.username AS attendee_name,
    v.name AS venue
FROM events e
JOIN registrations r ON e.event_id = r.event_id
JOIN users u ON u.user_id = r.user_id
JOIN venues v ON v.venue_id = e.venue_id;
