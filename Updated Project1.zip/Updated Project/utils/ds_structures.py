# Queue: Event registration order
class RegistrationQueue:
    def __init__(self):
        self.queue = []

    def enqueue(self, user_event):
        self.queue.append(user_event)

    def dequeue(self):
        return self.queue.pop(0) if self.queue else None

    def is_empty(self):
        return len(self.queue) == 0

# Stack: Undo registration
class UndoStack:
    def __init__(self):
        self.stack = []

    def push(self, registration):
        self.stack.append(registration)

    def pop(self):
        return self.stack.pop() if self.stack else None

    def is_empty(self):
        return len(self.stack) == 0
