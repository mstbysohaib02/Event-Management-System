from flask import Flask, render_template, request, redirect, url_for
from controllers.user_controller import register_user
from controllers.event_controller import add_event, get_all_events
from controllers.venue_controller import get_all_venues

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        register_user(username, email)
        return redirect(url_for('index'))
    return render_template('register_user.html')

@app.route('/add_event', methods=['GET', 'POST'])
def add_event_route():
    if request.method == 'POST':
        name = request.form['name']
        desc = request.form['description']
        date = request.form['date']
        time = request.form['time']
        venue_id = request.form['venue_id']
        add_event(name, desc, date, time, venue_id)
        return redirect(url_for('view_events'))
    
    venues = get_all_venues()
    return render_template('add_event.html', venues=venues)

@app.route('/events')
def view_events():
    events = get_all_events()
    return render_template('view_events.html', events=events)

if __name__ == '__main__':
    app.run(debug=True)
