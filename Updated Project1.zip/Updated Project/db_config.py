import mysql.connector

def get_connection():
    return mysql.connector.connect(
        host='localhost',        # or your server IP
        user='root',    # e.g., 'root'
        password='Muh@mmadhacci125',# your MySQL password
        database='event_mgmt_db'    # the database name
    )
